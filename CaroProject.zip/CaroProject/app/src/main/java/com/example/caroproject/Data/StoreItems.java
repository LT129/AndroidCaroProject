package com.example.caroproject.Data;

public class StoreItems extends Background{
    public StoreItems(int tempImage, int layoutBackground, int imageButtonBackground, int textViewBackground) {
        super(tempImage, layoutBackground, imageButtonBackground, textViewBackground);
    }
}
