package com.example.caroproject.Data;

public class Coins {
    private int copperCoins;


    public Coins(int copperCoins) {
        this.copperCoins = copperCoins;
    }

    public int getCopperCoins() {
        return copperCoins;
    }

    public void setCopperCoins(int copperCoins) {
        this.copperCoins = copperCoins;
    }
}
