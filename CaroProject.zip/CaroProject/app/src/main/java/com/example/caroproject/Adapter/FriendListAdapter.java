package com.example.caroproject.Adapter;

public class FriendListAdapter {


}
